<?php
/*
Plugin Name: Glitch Perspective-Post-Gallery
Description: Adds Vanilla Tilt functionality to your WordPress site.  
Version: 1.0
Author: Hassan Naqvi
Email: shrn496@gmail.com
*/

// Enqueue scripts and styles
function enqueue_vanilla_tilt_scripts() {
    // Enqueue Vanilla Tilt JavaScript
    wp_enqueue_script('vanilla-tilt', plugins_url('/js/vanilla-tilt.js', __FILE__), array(), '1.0', true);

    // Enqueue Typekit CSS
    wp_enqueue_style('typekit', 'https://use.typekit.net/ili2osz.css', array(), '1.0');

    // Enqueue base CSS
    wp_enqueue_style('base-css', plugins_url('/css/base-css.css', __FILE__), array(), '1.0');
}

add_action('wp_enqueue_scripts', 'enqueue_vanilla_tilt_scripts');

/*-------------------*/
// Define a function to retrieve posts by category and generate HTML
function custom_category_posts_shortcode($atts) {
    // Define shortcode attributes with a default category
    $atts = shortcode_atts(array(
              'category' => '', // Default category slug (empty for all categories)
        'posts_per_page' => -1,
    ), $atts);

    // Setup query arguments
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => $atts['posts_per_page'],
        'order' => 'DESC',
        'orderby' => 'date',
        'category_name' => $atts['category'],
    );

    // Query for posts
    $query = new WP_Query($args);

    // Start generating HTML
    ob_start();

    if ($query->have_posts()) {
        ?>
        <div class="content-grid">
        
         <!-- Outer div for content -->
    <?php
    $post_counter = 1; // Initialize the post counter

    while ($query->have_posts()) {
        $query->the_post();
        $featured_image_url = get_the_post_thumbnail_url();

        // Check if the post has a featured image, otherwise use a fallback image URL
         $fallback_image_url = plugins_url('img/1.png', __FILE__); // Adjust the path as needed

        ?>
        
        <figure class="item">
        
            <div class="item__img glitch" style="--img:url(<?php echo esc_url($featured_image_url ? $featured_image_url : $fallback_image_url); ?>);" data-tilt data-tilt-max="25" data-tilt-speed="3000" data-tilt-perspective="1500" data-tilt-scale="0.95" data-tilt-mouse-event-element=".content .item:nth-child(<?php echo esc_html($post_counter); ?>)">
            
                        
                <div class="glitch__img"></div>
                <div class="glitch__img"></div>
                <div class="glitch__img"></div>
                <div class="glitch__img"></div>
                <div class="glitch__img"></div>
            </div>
            <div class="item__cover" style="background-image:url(<?php echo esc_url($featured_image_url ? $featured_image_url : $fallback_image_url); ?>)"></div>
            <figcaption class="item__content">
            
    
          <div class="item__content-title" style="pointer-events: auto;">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </div>
                    
                <div class="item__content-label"><?php echo get_the_date('F j, Y'); ?></div>
            </figcaption>
         
        </figure>
        <script>
   
</script>
        

        <?php
        $post_counter++; // Increment the post counter
    }
    ?>
</div> <!-- End of outer div for content -->
 <!-- End of outer div for content -->
        <?php
        wp_reset_postdata();
    } else {
        echo '<p>No posts found.</p>';
    }

    // End generating HTML and return
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('tilt_grid_posts', 'custom_category_posts_shortcode');




// Add a menu item for the plugin settings page
function tilt_grid_posts_menu() {
    add_menu_page(
        'Tilt Grid Posts Settings',
        'Tilt Grid Posts',
        'manage_options',
        'tilt_grid_posts_settings',
        'tilt_grid_posts_settings_page'
    );
}

add_action('admin_menu', 'tilt_grid_posts_menu');

// Register settings for the plugin
function tilt_grid_posts_settings() {
    register_setting('tilt_grid_posts_settings_group', 'tilt_grid_posts_category');
}

// Create the plugin settings page
function tilt_grid_posts_settings_page() {
    ?>
    <div class="wrap">
        <h1>Tilt Grid Posts Settings</h1>
        <p>Configure the default category for the Tilt Grid Posts shortcode.</p>
        
        <h2>How to use the Tilt Grid Posts shortcode</h2>
        <p>Add the following shortcode to your posts or pages:</p>
        <code>[tilt_grid_posts]</code>
        <code>[tilt_grid_posts category="your_category_slug"]</code>
        <p>Replace <code>your_category_slug</code> with the desired category slug.</p>
    </div>
    <?php
}

